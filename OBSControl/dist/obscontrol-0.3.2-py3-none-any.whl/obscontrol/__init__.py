"""OBSControl desktop control-surface application."""

__version__ = "0.3.2"
